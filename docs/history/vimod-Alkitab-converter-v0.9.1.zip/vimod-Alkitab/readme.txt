Vimod Pub
Various Inputs Mutiple Output Digital Publishing
a toolchain
(Ian's prototyping, transformation, testing and publishing envirionment)

This is a set of (XP, Win7) files that can fairly quickly create various publishing outputs from one source.

This tool set is aimed at publishers doing digital publishing.

The working format is XML.

Input formats could be XML or XHTML, SFM or other structured text input.
The outputs could be XHTML, ePub (indirectly), DictionryForMids, PDF 
(PrinceXML or WkHtmltoPDF, one day maybe FOP), web pages, static page web app, 
 text files for Java Apps, Smart phone App content.

No DTD or schema is needed. The XML will most likely need some structure.

See GettingStarted.txt for the prerequisites to make this work on your system.

ian_mcquay@sil.org 
2013-03-05

updated 2013-09-28