# Restore standard PrintDraft-mods.tex.original to PrintDraft-mods.tex

# Written by Ian McQuay, SIL Publishing Asia, July 2013

# Import OS to be able to output correctly to Windows 
import os
# Read the MPP set by inner check
mppfile = "C:\\Users\\Public\\Documents\\mpp.txt"
if os.path.exists(mppfile):
    f = open(mppfile)
    mpp = f.read()
    f.close()

# set the two file variables
modsoriginalfile = mpp + '\\' + Project + '\\PrintDraft\\PrintDraft-mods.tex.original'
modsfile = mpp + '\\' + Project + '\\PrintDraft\\PrintDraft-mods.tex'
# delete the file with diglot settings and replace with original
if os.path.exists(modsfile):
    os.remove(modsfile)
#rename the PrintDraft-mods.tex.original to PrintDraft-mods.tex
if os.path.exists(modsoriginalfile):
    os.rename(modsoriginalfile, modsfile)


