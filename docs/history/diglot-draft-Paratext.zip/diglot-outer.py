# Rename standard PrintDraft-mods.tex to PrintDraft-mods.tex.original then generate diglot settings for outer language

# Written by Ian McQuay, SIL Publishing Asia, July 2013

# Import OS to be able to output correctly to Windows 
import os
mppfile = "C:\\Users\\Public\\Documents\\mpp.txt"
if os.path.exists(mppfile):
    f = open(mppfile)
    mpp = f.read()
    f.close()

# set the two file variables
modsfile = mpp + '\\' + Project + '\\PrintDraft\\PrintDraft-mods.tex'
modsoriginalfile = mpp + '\\' + Project + '\\PrintDraft\\PrintDraft-mods.tex.original'


#rename the original file to preserve it
if not os.path.exists(modsoriginalfile):
    os.rename(modsfile, modsoriginalfile)
command = "if not exist \"" + modsoriginalfile + "\" ren \"" + modsfile + "\" \"PrintDraft-mods.tex.original\""
os.system(command)
# remove previous file if not renamed
if os.path.exists(modsfile):
    os.remove(modsfile)
# write the lines for the diglot settings to PrintDraft-mods.tex
f = open(modsfile,'a')
f.write('%%%%% Page Setup for diglot outer (right lang on first page) %%%%%\n')
f.write('%% Margins\n')
f.write('\\BindingGutter=' + BindingGutter + '\n')
f.write('\\BindingGuttertrue\n')
f.write('\\FontSizeUnit=' + FontSizeUnit + '\n')
f.write('\\ParagraphedNotes{x}\n')
f.write('\\newlanguage\\printDraftLanguage\n')
f.write('\\language\\printDraftLanguage\n')
f.close()
