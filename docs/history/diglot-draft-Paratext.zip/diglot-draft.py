# Writes then starts the diglot-draft-combine.cmd batch file, 
# in order to combine two PDF files

# Written by Ian McQuay, SIL Publishing Asia, July 2013

# Import OS to be able to output correctly to Windows 
import os
mppfile = "C:\\Users\\Public\\Documents\\mpp.txt"
if os.path.exists(mppfile):
    f = open(mppfile)
    mpp = f.read()
    f.close()
    
# Define batch file
batchfile = "C:\\Users\\Public\\Documents\\diglot-draft-combine.cmd"
# delete batch file
if os.path.exists(batchfile):
    os.remove(batchfile)
# write the lines for the diglot settings to PrintDraft-mods.tex
f = open(batchfile,'a')
f.write('@echo off\n')
f.write('set mpp=' + mpp + '\n')
f.write('set draftbook=' + draftbook + '\n')
f.write('set innerver=' + innerver + '\n')
f.write('set outerver=' + Project + '\n')
f.write('set pdftk=' + pdftk + '\n')
f.write('set pdftk=' + pdftk + '\n')

f.write('set file2=%mpp%\\%innerver%\\PrintDraft\\printdraft-%innerver%-%draftbook%.pdf\n')
f.write('set file1=%mpp%\\%outerver%\\PrintDraft\\printdraft-%outerver%-%draftbook%.pdf\n')
f.write('set diglot=%mpp%\\%outerver%\\PrintDraft\\diglotdraft-%outerver%-%innerver%-%draftbook%.pdf\n')
f.write('set report=File not found! %pdftk%\n')
f.write('if not exist \"%pdftk%\" goto :error\n')
f.write('set report=Folder not found! %mpp%\n')
f.write('if not exist \"%mpp%\" goto :error\n')
f.write("\"%pdftk%\" \"%file1%\" multibackground \"%file2%\" output \"%diglot%\"\n")
#f.write("echo \"%errorlevel%\"\n")
f.write("if %errorlevel% == 0 echo Success!\n")
f.write("pause\n")
f.write("goto :eof\n")
f.write(":error\n")
f.write("echo %report%\n")
f.write("echo Checks your Options are correct in Paratext check\n")
f.write("echo The batch file will exit\n")
f.write("pause\n")
f.write("exit /b 1\n")
f.write("goto :eof\n")
f.close()
# call the just written file
os.startfile(batchfile)
