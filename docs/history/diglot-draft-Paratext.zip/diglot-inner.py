# Rename standard PrintDraft-mods.tex to PrintDraft-mods.tex.original then generate diglot settings for inner language

# Written by Ian McQuay, SIL Publishing Asia, July 2013

# Import OS to be able to output correctly to Windows 
import os
mppfile = "C:\\Users\\Public\\Documents\\mpp.txt"
# fix for Win XP
if not os.path.exists('C:\\Users\\Public\\Documents'):
    os.makedirs('C:\\Users\\Public\\Documents')
# write a file with the MPP path in it
if not os.path.exists(mppfile):
    f = open(mppfile,'w')
    f.write(setmpp)
# reads a file with the MPP path in it
if os.path.exists(mppfile):
    f = open(mppfile)
    mpp = f.read()
    f.close()

# set the two file variables
modsfile = mpp + '\\' + Project + '\\PrintDraft\\PrintDraft-mods.tex'
modsoriginalfile = mpp + '\\' + Project + '\\PrintDraft\\PrintDraft-mods.tex.original'
# write to batch file echo off. Overwrite previous file.

#rename the original file to preserve it
if not os.path.exists(modsoriginalfile):
    os.rename(modsfile, modsoriginalfile)
# remove previous file if not renamed
if os.path.exists(modsfile):
    os.remove(modsfile)

# write the lines for the diglot settings to PrintDraft-mods.tex
f = open(modsfile,'a')
f.write('%%%%% Page Setup for diglot inner (left lang on first page) %%%%%\n')
f.write('%% Margins\n')
f.write('\\BindingGutter=' + BindingGutter + '\n')
f.write('\\BindingGuttertrue\n')
f.write('\\def\\SideMarginFactor{' + SideMarginFactor + '}\n')
f.write('\\FontSizeUnit=' + FontSizeUnit + '\n')
f.write('\\ParagraphedNotes{x}\n')
f.write('\\newlanguage\\printDraftLanguage\n')
f.write('\\language\\printDraftLanguage\n')
f.close()