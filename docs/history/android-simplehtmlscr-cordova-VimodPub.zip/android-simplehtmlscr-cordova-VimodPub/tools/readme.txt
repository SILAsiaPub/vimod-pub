This tools folder hold sub folders that contain external tools that 
can be intergrated via the plugin function.